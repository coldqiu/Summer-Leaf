export default function Search(props) {
  return <h1>Search Page</h1>;
}
