// import TabList from "../../components/TabList";
import Test from "@/test";
import Style from "./index.less";

export default function Collection(props) {
  return (
    <div className={Style.collection}>
      {/* <TabList /> */}
      <h1>Collection</h1>
      <Test />
    </div>
  );
}
