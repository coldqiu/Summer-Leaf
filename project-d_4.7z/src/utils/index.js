// 打乱列表顺序，生成随机列表
export function shuffle(list) {
  return list;
}
