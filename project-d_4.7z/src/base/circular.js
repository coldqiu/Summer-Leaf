import Style from './circular.less'


export default function Circular(radius) {
  return <div className={Style.circular}></div>;
}
